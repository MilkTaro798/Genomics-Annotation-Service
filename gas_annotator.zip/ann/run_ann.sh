#!/bin/bash

# run_ann.sh
cd /home/ec2-user/mpcs-cc/gas/ann
source /home/ec2-user/mpcs-cc/bin/activate
python annotator.py